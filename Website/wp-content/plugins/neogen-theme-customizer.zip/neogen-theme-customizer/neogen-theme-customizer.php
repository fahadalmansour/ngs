<?php
/**
 * Plugin Name: Neogen Theme Customizer
 * Description: Unifi-inspired dark/light mode with Arabic/English toggle for neogen store
 * Version: 1.0.0
 * Author: neogen
 * Text Domain: neogen-theme
 */

defined('ABSPATH') || exit;

class Neogen_Theme_Customizer {

    public function __construct() {
        add_action('wp_enqueue_scripts', [$this, 'enqueue_styles'], 999);
        add_action('wp_footer', [$this, 'enqueue_scripts'], 999);
        add_action('wp_head', [$this, 'add_preload_theme']);
    }

    /**
     * Preload theme to prevent flash
     */
    public function add_preload_theme() {
        ?>
        <script>
            // Prevent flash of wrong theme
            (function() {
                var theme = localStorage.getItem('neogen-theme');
                var lang = localStorage.getItem('neogen-lang') || 'ar';

                if (theme) {
                    document.documentElement.setAttribute('data-theme', theme);
                } else if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
                    document.documentElement.setAttribute('data-theme', 'dark');
                }

                document.documentElement.setAttribute('lang', lang);
                document.documentElement.setAttribute('dir', lang === 'en' ? 'ltr' : 'rtl');
            })();
        </script>
        <meta name="theme-color" content="#0a0a0a">
        <?php
    }

    /**
     * Enqueue custom CSS
     */
    public function enqueue_styles() {
        // Add inline CSS (comprehensive styles)
        wp_add_inline_style('blocksy-frontend', $this->get_custom_css());
    }

    /**
     * Enqueue toggle script
     */
    public function enqueue_scripts() {
        ?>
        <script>
        <?php echo $this->get_toggle_js(); ?>
        </script>
        <?php
    }

    /**
     * Get custom CSS
     */
    private function get_custom_css() {
        return <<<'CSS'
/* neogen Theme Customizer - Unifi Style */

:root,
[data-theme="light"] {
    --neogen-primary: #1F1EFB;
    --neogen-secondary: #0D2175;
    --neogen-accent: #4F4EFC;
    --neogen-bg: #FFFFFF;
    --neogen-bg-alt: #F8F9FA;
    --neogen-bg-card: #FFFFFF;
    --neogen-header-bg: #0a0a0a;
    --neogen-footer-bg: #0D2175;
    --neogen-text: #1a1a2e;
    --neogen-text-secondary: #4B5563;
    --neogen-text-muted: #6B7280;
    --neogen-border: #E5E7EB;
    --neogen-border-hover: #1F1EFB;
    --neogen-success: #10B981;
    --neogen-warning: #F59E0B;
    --neogen-error: #EF4444;
    --neogen-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
    --neogen-shadow-lg: 0 10px 15px -3px rgba(0,0,0,0.1);
    --neogen-gradient: linear-gradient(135deg, #0D2175 0%, #1F1EFB 100%);
}

[data-theme="dark"] {
    --neogen-primary: #4F4EFC;
    --neogen-secondary: #1F1EFB;
    --neogen-accent: #7C7CFF;
    --neogen-bg: #0a0a0a;
    --neogen-bg-alt: #111111;
    --neogen-bg-card: #1a1a1a;
    --neogen-header-bg: #000000;
    --neogen-footer-bg: #000000;
    --neogen-text: #FFFFFF;
    --neogen-text-secondary: #D1D5DB;
    --neogen-text-muted: #9CA3AF;
    --neogen-border: #2a2a2a;
    --neogen-border-hover: #4F4EFC;
    --neogen-shadow: 0 4px 6px -1px rgba(0,0,0,0.3);
    --neogen-shadow-lg: 0 10px 15px -3px rgba(0,0,0,0.4);
    --neogen-gradient: linear-gradient(135deg, #1F1EFB 0%, #4F4EFC 100%);
}

* { transition: background-color 0.3s ease, color 0.3s ease, border-color 0.3s ease; }
body { background: var(--neogen-bg); color: var(--neogen-text); font-family: 'Tajawal', 'Inter', sans-serif; }

/* Controls */
.neogen-controls { position: fixed; bottom: 20px; left: 20px; z-index: 9999; display: flex; flex-direction: column; gap: 10px; }
[dir="rtl"] .neogen-controls { left: auto; right: 20px; }
.neogen-toggle-btn { width: 50px; height: 50px; border-radius: 50%; border: 2px solid var(--neogen-border); background: var(--neogen-bg-card); color: var(--neogen-text); cursor: pointer; font-size: 1.2rem; box-shadow: var(--neogen-shadow-lg); transition: all 0.3s; display: flex; align-items: center; justify-content: center; }
.neogen-toggle-btn:hover { transform: scale(1.1); border-color: var(--neogen-primary); }
.lang-toggle { background: var(--neogen-primary) !important; color: white !important; border: none !important; font-weight: 700; font-size: 0.85rem; }

/* Header - Always Dark */
header, .site-header, .ct-header, #masthead { background: var(--neogen-header-bg) !important; }
header a, .ct-header a, .site-header a { color: #fff !important; }
header a:hover, .ct-header a:hover { color: var(--neogen-primary) !important; }
.ct-cart-count, .cart-count { background: var(--neogen-primary) !important; }

/* Buttons */
.button, .btn, .wp-block-button__link, .woocommerce a.button, .woocommerce button.button, .ct-button, .elementor-button, button[type="submit"], input[type="submit"] {
    background: var(--neogen-gradient) !important;
    color: #fff !important;
    border: none !important;
    border-radius: 10px !important;
    padding: 14px 28px !important;
    font-weight: 600 !important;
    box-shadow: var(--neogen-shadow) !important;
    transition: all 0.3s !important;
}
.button:hover, .btn:hover, .woocommerce a.button:hover, .elementor-button:hover { transform: translateY(-3px); box-shadow: var(--neogen-shadow-lg) !important; }

/* Products */
.woocommerce ul.products li.product, .ct-woo-card-inner { background: var(--neogen-bg-card) !important; border: 1px solid var(--neogen-border) !important; border-radius: 16px !important; transition: all 0.3s !important; }
.woocommerce ul.products li.product:hover { transform: translateY(-10px); box-shadow: var(--neogen-shadow-lg) !important; border-color: var(--neogen-border-hover) !important; }
.woocommerce ul.products li.product .woocommerce-loop-product__title { color: var(--neogen-text) !important; }
.woocommerce ul.products li.product .price { color: var(--neogen-primary) !important; font-weight: 700 !important; font-size: 1.2rem !important; }
.woocommerce span.onsale { background: var(--neogen-error) !important; border-radius: 8px !important; }

/* Single Product */
.woocommerce div.product .product_title { color: var(--neogen-text) !important; }
.woocommerce div.product p.price { color: var(--neogen-primary) !important; font-size: 1.8rem !important; }
.woocommerce div.product .woocommerce-tabs ul.tabs li a { color: var(--neogen-text-muted) !important; }
.woocommerce div.product .woocommerce-tabs ul.tabs li.active a { color: var(--neogen-primary) !important; border-bottom: 3px solid var(--neogen-primary); }

/* Forms */
input[type="text"], input[type="email"], input[type="tel"], input[type="password"], input[type="number"], textarea, select {
    background: var(--neogen-bg-card) !important;
    border: 2px solid var(--neogen-border) !important;
    border-radius: 10px !important;
    padding: 14px !important;
    color: var(--neogen-text) !important;
}
input:focus, textarea:focus, select:focus { border-color: var(--neogen-primary) !important; box-shadow: 0 0 0 4px rgba(31,30,251,0.1) !important; }

/* Cart & Checkout */
.woocommerce-cart-form table, .cart_totals, .woocommerce-checkout-review-order { background: var(--neogen-bg-card) !important; border-radius: 16px !important; border: 1px solid var(--neogen-border) !important; }
.woocommerce-cart-form table th { background: var(--neogen-bg-alt) !important; color: var(--neogen-text) !important; }
.woocommerce-cart-form table td { color: var(--neogen-text) !important; border-color: var(--neogen-border) !important; }

/* Footer */
footer, .site-footer, #colophon { background: var(--neogen-footer-bg) !important; color: #fff !important; }
.site-footer h4, .footer-widget h4 { color: var(--neogen-accent) !important; }
.site-footer a { color: rgba(255,255,255,0.8) !important; }
.site-footer a:hover { color: var(--neogen-primary) !important; }

/* Sections */
section, .elementor-section { background: var(--neogen-bg); }
section:nth-child(even), .elementor-section:nth-child(even) { background: var(--neogen-bg-alt); }
h2.elementor-heading-title { color: var(--neogen-text) !important; }

/* Dark mode scrollbar */
[data-theme="dark"] ::-webkit-scrollbar { width: 10px; }
[data-theme="dark"] ::-webkit-scrollbar-track { background: #111; }
[data-theme="dark"] ::-webkit-scrollbar-thumb { background: #333; border-radius: 5px; }

/* Responsive */
@media (max-width: 767px) {
    .neogen-controls { bottom: 15px; left: 15px; }
    [dir="rtl"] .neogen-controls { left: auto; right: 15px; }
    .neogen-toggle-btn { width: 45px; height: 45px; }
}
CSS;
    }

    /**
     * Get toggle JavaScript
     */
    private function get_toggle_js() {
        return <<<'JS'
(function(){
    document.addEventListener('DOMContentLoaded', function() {
        // Create controls
        var controls = document.createElement('div');
        controls.className = 'neogen-controls';
        controls.innerHTML = '<button class="neogen-toggle-btn theme-toggle" title="Toggle Theme"></button><button class="neogen-toggle-btn lang-toggle">EN</button>';
        document.body.appendChild(controls);

        // Theme toggle
        var themeBtn = controls.querySelector('.theme-toggle');
        var currentTheme = document.documentElement.getAttribute('data-theme') || 'light';
        themeBtn.textContent = currentTheme === 'dark' ? '☀️' : '🌙';

        themeBtn.addEventListener('click', function() {
            var theme = document.documentElement.getAttribute('data-theme');
            var newTheme = theme === 'dark' ? 'light' : 'dark';
            document.documentElement.setAttribute('data-theme', newTheme);
            localStorage.setItem('neogen-theme', newTheme);
            themeBtn.textContent = newTheme === 'dark' ? '☀️' : '🌙';
        });

        // Language toggle
        var langBtn = controls.querySelector('.lang-toggle');
        var currentLang = localStorage.getItem('neogen-lang') || 'ar';
        langBtn.textContent = currentLang === 'ar' ? 'EN' : 'ع';

        langBtn.addEventListener('click', function() {
            var lang = localStorage.getItem('neogen-lang') || 'ar';
            var newLang = lang === 'ar' ? 'en' : 'ar';
            document.documentElement.setAttribute('lang', newLang);
            document.documentElement.setAttribute('dir', newLang === 'en' ? 'ltr' : 'rtl');
            localStorage.setItem('neogen-lang', newLang);
            langBtn.textContent = newLang === 'ar' ? 'EN' : 'ع';
            location.reload(); // Reload to apply language (if using WPML/Polylang)
        });
    });
})();
JS;
    }
}

new Neogen_Theme_Customizer();
